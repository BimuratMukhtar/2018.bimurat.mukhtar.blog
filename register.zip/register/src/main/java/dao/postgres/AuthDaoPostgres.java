package dao.postgres;

import dao.AuthDao;
import kz.greetgo.depinject.core.Bean;

@Bean
public interface AuthDaoPostgres extends AuthDao {

}
