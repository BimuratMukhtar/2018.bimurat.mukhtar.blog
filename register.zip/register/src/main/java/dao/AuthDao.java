package dao;

public interface AuthDao {
}
