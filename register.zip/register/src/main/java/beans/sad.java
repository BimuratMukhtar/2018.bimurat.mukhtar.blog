package beans;

public class sad {
}
