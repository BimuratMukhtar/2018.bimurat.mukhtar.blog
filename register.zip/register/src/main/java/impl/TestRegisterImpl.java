package impl;

public class TestRegisterImpl {
}
