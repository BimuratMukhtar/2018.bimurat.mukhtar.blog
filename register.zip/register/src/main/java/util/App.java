package util;

public class App {
    public String dir(){
        return "blog";
    }
}
