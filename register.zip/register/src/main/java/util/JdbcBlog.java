package util;

import kz.greetgo.db.AbstractJdbcWithDataSource;
import kz.greetgo.db.TransactionManager;

import javax.sql.DataSource;

public class JdbcBlog extends AbstractJdbcWithDataSource {

    @Override
    protected DataSource getDataSource() {
        return null;
    }

    @Override
    protected TransactionManager getTransactionManager() {
        return null;
    }
}
